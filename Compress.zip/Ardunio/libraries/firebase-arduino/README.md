# FirebaseArduino

Working library backup from https://github.com/FirebaseExtended/firebase-arduino
Fix problem can not read and write to firebase

## Disclaimer

*This is not an official Google product*.
